#include "pathCell.h"
#include "cell.h"

pathCell::pathCell(myTuple* givenLocation,float givenProb,int givenId,float givenCost) : cell(givenLocation,givenProb,givenId) {
	this->cost = givenCost;
	this->lastCell = NULL;
}
//Set the cost of the cell
void pathCell::setCost(float newCost) {this->cost = newCost;}

//return the last cell of the path.
pathCell* pathCell::getLastCell() {return this->lastCell;}

//get the cost of the cell.
float pathCell::getCost() {return this->cost;}

//set the last path cell.
void pathCell::setLastPathCell(pathCell* lastOne) { this->lastCell = lastOne;}