#ifndef GRID_H
#define GRID_H


#include <ros/ros.h>
#include <iostream>
#include <vector>
#include "pathCell.h"


class grid {
private:
	vector<vector <pathCell*> > cells;
	int rows;
	int cols;
	vector<vector<float> > myGrid; 
	void initGrid(float a[9][9]);
	void readMap();
public:
	grid(float a[9][9]);
	pathCell* getCellAt(int i,int j);

};

#endif