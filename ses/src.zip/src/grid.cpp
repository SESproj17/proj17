#include "grid.h"
#include <nav_msgs/GetMap.h>


grid::grid(float a[9][9]) {
	this->initGrid(a);
}

//return cell at (i,j)
pathCell* grid::getCellAt(int i,int j) {
	return ((this->cells[i])[j]);
}

//Initialize the grid
void grid::initGrid(float a[9][9]) {
	this->rows = 9;
	this->cols = 9;
	this->cells.resize(this->rows);
	for (int i = 0; i < this->rows; ++i) {
		cells[i].resize(this->cols);
	}
	cout << "START " << endl;
	int id = 0;
	for (int i = 0; i < this->rows; ++i) { 
		for (int j = 0; j < this->cols; ++j)
		{

			cells[i][j] = new pathCell(new myTuple(i,j),a[i][j],id,-1);
			id++;
			cout << a[i][j] << " ";
		}
		cout << endl;
	}
}

void grid::readMap() {
	int currCell = 0;
	ros::NodeHandle nh;
    while (!ros::service::waitForService("static_map", ros::Duration(3.0))) {
        ROS_INFO("Waiting for service static_map to become available");
    }
    ros::ServiceClient mapClient = nh.serviceClient<nav_msgs::GetMap>("static_map");
    nav_msgs::GetMap::Request req;
    nav_msgs::GetMap::Response res;
    if (!mapClient.call(req, res)) {ROS_INFO("NOT FOUND\n");}
    const nav_msgs::OccupancyGrid& map = res.map;
    this->rows = map.info.height;
    this->cols = map.info.width;
    myGrid.resize(rows);
    for (int i = 0; i < rows; i++) {
        myGrid[i].resize(cols);   
    }
    cout << "start " << endl;
    cout << " ROWSSSSSS " << rows << " COLSSSS " << cols << endl;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
        	//cout << map.data[currCell];
            myGrid[i][j] = (float)(map.data[currCell])/100;
            cout << myGrid[i][j];
            currCell++;
        }
        cout << endl;
    }
}